"""Layout-only containers for existing project controls and log widgets."""
import tkinter as tk
from tkinter import ttk

from src.ui.module_theme import MODULE_BACKGROUND


def trim_log_display(widget, *, max_lines=5000, max_chars=1024 * 1024):
    """Bound only the visible Text tail; the caller retains its complete log file."""
    lines = int(widget.index('end-1c').split('.')[0])
    if lines > max_lines:
        widget.delete('1.0', f'{lines - max_lines + 1}.0')
    chars = (widget.count('1.0', 'end-1c', 'chars') or (0,))[0]
    if chars > max_chars:
        widget.delete('1.0', f'1.0 + {chars - max_chars} chars')


def wrap_navigation(toolbar):
    """Wrap the existing buttons without replacing their commands or ownership."""
    widgets = toolbar.winfo_children()
    for widget in widgets:
        widget.pack_forget()
    previous = []
    def arrange(event):
        row, used = 0, 0
        row_height = max(widget.winfo_reqheight() for widget in widgets) + 4
        positions = []
        for widget in widgets:
            width = widget.winfo_reqwidth() + 8
            if used and used + width > event.width:
                row, used = row + 1, 0
            positions.append((used, row * row_height))
            used += width
        if positions != previous:
            previous[:] = positions
            for widget, (x, y) in zip(widgets, positions):
                widget.place(x=x, y=y, height=row_height - 4)
            toolbar.configure(height=(row + 1) * row_height)
    toolbar.bind('<Configure>', arrange, add='+')


class WorkbenchPanels(tk.Frame):
    def __init__(self, parent):
        super().__init__(parent, background=MODULE_BACKGROUND)
        self.config_area = tk.Frame(self, background=MODULE_BACKGROUND, width=300)
        self.config_area.pack(side='right', fill='y', padx=(12, 0))
        self.config_area.pack_propagate(False)
        config_canvas = self.config_canvas = tk.Canvas(self.config_area, background=MODULE_BACKGROUND, highlightthickness=0)
        horizontal = ttk.Scrollbar(self.config_area, orient='horizontal', command=config_canvas.xview)
        horizontal.pack(side='bottom', fill='x')
        config_scroll = ttk.Scrollbar(self.config_area, orient='vertical', command=config_canvas.yview)
        config_canvas.configure(yscrollcommand=config_scroll.set, xscrollcommand=horizontal.set)
        config_scroll.pack(side='right', fill='y')
        config_canvas.pack(fill='both', expand=True)
        self.config_content = ttk.Frame(config_canvas, style='App.TFrame')
        self.config_window = config_canvas.create_window(0, 0, anchor='nw', window=self.config_content)
        config_canvas.bind('<Configure>', self._resize_config)
        self.config_content.bind('<Configure>', self._resize_config)
        self.panes = tk.PanedWindow(self, orient='vertical', sashwidth=7, sashrelief='flat',
                                   background=MODULE_BACKGROUND, borderwidth=0)
        self.panes.pack(fill='both', expand=True)
        top = tk.Frame(self.panes, background=MODULE_BACKGROUND)
        self.panes.add(top, minsize=140, stretch='always')
        self.canvas = tk.Canvas(top, background=MODULE_BACKGROUND, highlightthickness=0)
        vertical = ttk.Scrollbar(top, orient='vertical', command=self.canvas.yview)
        self.canvas.configure(yscrollcommand=vertical.set)
        top.rowconfigure(0, weight=1)
        top.columnconfigure(0, weight=1)
        self.canvas.grid(row=0, column=0, sticky='nsew')
        vertical.grid(row=0, column=1, sticky='ns')
        self.content = ttk.Frame(self.canvas, style='App.TFrame')
        self.window_id = self.canvas.create_window(0, 0, anchor='nw', window=self.content)
        self.canvas.bind('<Configure>', self._resize)
        self.content.bind('<Configure>', self._resize)
        self.log_host = ttk.Frame(self.panes, style='Surface.TFrame')
        self.panes.add(self.log_host, minsize=70, height=220, stretch='never')
        self.config_visible = True
        self.log_visible = True

    def _resize(self, event=None):
        width = self.canvas.winfo_width()
        if int(float(self.canvas.itemcget(self.window_id, 'width'))) != width:
            self.canvas.itemconfigure(self.window_id, width=width)
        self.canvas.configure(scrollregion=self.canvas.bbox('all'))

    def _resize_config(self, event=None):
        width = self.config_canvas.winfo_width()
        if vars(self).get('config_visible', True):
            width = max(width, self.config_content.winfo_reqwidth())
        if int(float(self.config_canvas.itemcget(self.config_window, 'width'))) != width:
            self.config_canvas.itemconfigure(self.config_window, width=width)
        self.config_canvas.configure(scrollregion=self.config_canvas.bbox('all'))

    def attach_config(self, card, header, bodies, summary):
        self.config_bodies = bodies
        self.summary = summary
        self.config_summary = tk.StringVar(self)
        self.summary_label = ttk.Label(card, textvariable=self.config_summary, style='CardHint.TLabel', wraplength=600)
        self.summary_label.bind('<Configure>', lambda event: self.summary_label.configure(
            wraplength=max(100, event.width - 4)))
        self.config_toggle = ttk.Button(header, text='收起配置', command=self.toggle_config, style='Tool.TButton')
        self.config_toggle.pack(side='right', padx=8)

    def refresh_summary(self):
        if not self.config_visible:
            self.config_summary.set(self.summary())

    def toggle_config(self):
        self.config_visible = not self.config_visible
        if self.config_visible:
            self.summary_label.pack_forget()
            for widget, options in self.config_bodies:
                widget.pack(**options)
        else:
            self.config_summary.set(self.summary())
            for widget, _ in self.config_bodies:
                widget.pack_forget()
            self.summary_label.pack(fill='x', pady=(8, 0))
        self.config_toggle.configure(text='收起配置' if self.config_visible else '编辑配置')

    def attach_log(self, header, body):
        self.log_body = body
        self.log_toggle = ttk.Button(header, text='收起日志', command=self.toggle_log, style='Secondary.TButton')
        self.log_toggle.pack(side='right', padx=8)

    def toggle_log(self):
        self.log_visible = not self.log_visible
        self.log_toggle.configure(text='收起日志' if self.log_visible else '展开日志')
        if self.log_visible:
            self.log_body.pack(fill='both', expand=True)
            self.panes.paneconfigure(self.log_host, minsize=70, height=220)
        else:
            self.log_body.pack_forget()
            self.panes.paneconfigure(self.log_host, minsize=48, height=48)


class HorizontalConfig(tk.Frame):
    """Keep wide existing parameter forms reachable without widening run controls."""
    def __init__(self, parent):
        super().__init__(parent, background='#ffffff')
        self.canvas = tk.Canvas(self, background='#ffffff', highlightthickness=0, height=1)
        self.canvas.pack(fill='x')
        scroll = ttk.Scrollbar(self, orient='horizontal', command=self.canvas.xview)
        scroll.pack(fill='x')
        self.canvas.configure(xscrollcommand=scroll.set)
        self.content = ttk.Frame(self.canvas, style='Surface.TFrame')
        self.window_id = self.canvas.create_window(0, 0, anchor='nw', window=self.content)
        self.content.bind('<Configure>', self._resize)
        self.canvas.bind('<Configure>', self._resize)

    def _resize(self, event=None):
        height = self.content.winfo_reqheight()
        if int(self.canvas.cget('height')) != height:
            self.canvas.configure(height=height)
        width = max(self.content.winfo_reqwidth(), self.canvas.winfo_width())
        if int(float(self.canvas.itemcget(self.window_id, 'width'))) != width:
            self.canvas.itemconfigure(self.window_id, width=width)
        self.canvas.configure(scrollregion=self.canvas.bbox('all'))
